classdef Simplex2D < handle
% -----------------------------------------------------------------------------
% 2D-Simplex class definition.
% The reference 2D-simplex follows the convention:
% Vertices:
%             v1 = (0.0, 0.0)
%             v2 = (1.0, 0.0)
%             v3 = (0.0, 1.0)
% Edges:
%             e1: (v2,v3); 
%             e2: (v3,v1); 
%             e3: (v1,v2).
% -----------------------------------------------------------------------------



% -----------------------------------------------------------------------------
%                          PROPERTIES SECTION
% -----------------------------------------------------------------------------

properties ( Access = private )
	ie_; % 3x1 array of edge index
	iv_; % 3x1 array of vertex index
	v_; % 2x3 array of vertex coordinates
	j_; % 2x2 matrix Jacobian of linear mapping
	n_; % 2x3 array coordinates of normal vectors
	e_; % 1x3 array edge lengths
end

% -----------------------------------------------------------------------------
%                         STATIC METHODS SECTION
% -----------------------------------------------------------------------------

methods (Static)

	[edgeConnectivity] = getEdgeConnectivity();

end


% -----------------------------------------------------------------------------
%                          METHODS SECTION
% -----------------------------------------------------------------------------
methods

function T = Simplex2D(varargin)
% -----------------------------------------------------------------------------
% 2D-simplex constructor:
%
%     Simplex2D()  the reference 2D-simplex is created.
%
%     Simplex2D(vertexList) vertexList is a 2x3 array with vertex coordinates
%
%     Simplex2D(V1,V2,V3)  Vi is a 2x1 array with the coordinates of vertex i 
% -----------------------------------------------------------------------------
	T.v_ = zeros(2,3);
	optargin = size(varargin,2);
	switch optargin
	case 0
		T.v_ = [0 1 0;0 0 1];     % REFERENCE TRIANGLE
	case 1
		T.v_ = varargin{1};
	case 4
		T.v_(:,1) = varargin{1};
		T.v_(:,2) = varargin{2};
		T.v_(:,3) = varargin{3};
		T.iv_ = varargin{4};
	otherwise
		error('Hmmm! in Simplex2D(): number of input parameters must be 0,1 or 3')
	end
	if(optargin ~= 0)
	% ------------------------------- jacobian ----------------------------------
		T.j_ = zeros(2);
		T.j_(:,1) = T.v_(:,2) - T.v_(:,1);
		T.j_(:,2) = T.v_(:,3) - T.v_(:,1);
	%------------------------ normals and edge lengths --------------------------
		T.n_ = zeros(2,3);
		T.e_ = zeros(1,3);
	% Normal relative to edge 1: (v2 v3)
		nv = [ T.v_(2,3) - T.v_(2,2)
			  T.v_(1,2) - T.v_(1,3) ];
		edgeLength = norm(nv);
		T.e_(1) = edgeLength;
		T.n_(:,1) = nv/edgeLength;
	% Normal relative to edge 2: (v3 v1)
		nv = [ T.v_(2,1) - T.v_(2,3)
			T.v_(1,3) - T.v_(1,1) ];
		edgeLength = norm(nv);
		T.e_(2) = edgeLength;
		T.n_(:,2) = nv/edgeLength;
	% Normal relative to edge 3: (v1 v2)
		nv = [ T.v_(2,2) - T.v_(2,1)
			T.v_(1,1) - T.v_(1,2) ];
		edgeLength = norm(nv);
		T.e_(3) = edgeLength;
		T.n_(:,3) = nv/edgeLength;
	end
end


	[] =  setVertices(T,vertexList, vertexIndex, edgeIndex);
	[vertexList] = getVertices(T);
	[vertex] = getVertex(T,i);
	[iVertex] = getVertexIndex(T);
	[iEdges] = getEdgeIndex(T);
	[J] = getJacobian(T);	
	[area] = getArea(T);
	[detJ] = getDetJac(T);
	[ni] = getNormal(T,i);
	[normals] = getNormalList(T);
	[li] = getLength(T,i);
	[l] = getLengthList(T);
	[x] = mapPoints(T,xo);
	[G] = getBarycenter(T);
	[m] = getQualityMeasures(T);
	[diam] = getDiameter(T);

end											% END OF METHODS SECTION

% -----------------------------------------------------------------------------
%                          END OF CLASS DEFINITION
% -----------------------------------------------------------------------------
end


% ------------------------------------------------------------------------------
%                               END OF FILE
% ------------------------------------------------------------------------------




% -----------------------------------------------------------------------------
% Created by 
%
% Paul Castillo, paul.castillo@upr.edu
% Department of Mathematical Sciences 
% University of Puerto Rico, Mayaguez Campus (UPRM)
%
% Sergio Gomez, sergio.gomezmacias@unimib.it
% Department of Mathematics and Applications
% University of Milano-Bicocca (UNIMIB)
%
%                                   (2020)
% -----------------------------------------------------------------------------