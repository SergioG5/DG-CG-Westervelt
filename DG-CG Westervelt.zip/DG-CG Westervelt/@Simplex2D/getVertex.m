function [vertex] = getVertex(T,i)
% ------------------------------------------------------------------------------
%  vertex = getVertex(i) gets coordinates (2x1 array) of vertex i.
% ------------------------------------------------------------------------------
	vertex = T.v_(:,i);
end

% -----------------------------------------------------------------------------
% Created by 
%
% Paul Castillo, paul.castillo@upr.edu
% Department of Mathematical Sciences 
% University of Puerto Rico, Mayaguez Campus (UPRM)
%
% Sergio Gomez, sergio.gomezmacias@unimib.it
% Department of Mathematics and Applications
% University of Milano-Bicocca (UNIMIB)
%
%                                   (2020)
% -----------------------------------------------------------------------------