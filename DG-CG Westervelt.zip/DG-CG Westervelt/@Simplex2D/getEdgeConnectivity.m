function [edgeConnectivity] = getEdgeConnectivity()
% ------------------------------------------------------------------------------
% Get edge connectivity: 3x2 array 
%
%           edgeConnectivity(1,i) index of node 1 in edge i 
%           edgeConnectivity(2,i) index of node 2 in edge i
%
% ------------------------------------------------------------------------------
	edgeConnectivity = [  2 3 1
												3 1 2];
end

% -----------------------------------------------------------------------------
% Created by 
%
% Paul Castillo, paul.castillo@upr.edu
% Department of Mathematical Sciences 
% University of Puerto Rico, Mayaguez Campus (UPRM)
%
% Sergio Gomez, sergio.gomezmacias@unimib.it
% Department of Mathematics and Applications
% University of Milano-Bicocca (UNIMIB)
%
%                                   (2020)
% -----------------------------------------------------------------------------