function [J] = getJacobian(T)
% ------------------------------------------------------------------------------
% J = getJacobian() gets jacobian 2x2 matrix of local mapping from the refence 
%                   simplex 
%                       To = [ 0 1 0
%                              0 0 1]
%                   to current simplex.
% ------------------------------------------------------------------------------
	J = T.j_;
end

% -----------------------------------------------------------------------------
% Created by 
%
% Paul Castillo, paul.castillo@upr.edu
% Department of Mathematical Sciences 
% University of Puerto Rico, Mayaguez Campus (UPRM)
%
% Sergio Gomez, sergio.gomezmacias@unimib.it
% Department of Mathematics and Applications
% University of Milano-Bicocca (UNIMIB)
%
%                                   (2020)
% -----------------------------------------------------------------------------